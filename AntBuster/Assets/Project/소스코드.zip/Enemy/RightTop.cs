using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RightTop : MonoBehaviour
{
    GameObject rTop;
    // Start is called before the first frame update
    void Start()
    {
        rTop = GetComponent<GameObject>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
